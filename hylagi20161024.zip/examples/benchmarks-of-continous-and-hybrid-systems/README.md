Benchmarks in this directory are derived from 
"A Toolbox for the Reachability Analysis of Hybrid Systems using Geometric Approximations (HyPro)"
http://ths.rwth-aachen.de/research/projects/hypro/

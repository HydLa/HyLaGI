#pragma once

namespace hydla{
namespace backend{
namespace mathematica{
const char* math_source();
}
}
}

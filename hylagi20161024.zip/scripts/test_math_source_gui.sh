#!/bin/sh

mathematica test_math_source.m
#!/bin/sh

rlwrap math -run "<<./scripts/test_math_source.m"
